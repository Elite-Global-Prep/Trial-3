import Count from "./components/Count";

const App = () => {
  return (
    <div>
      <Count />
    </div>
  );
};

export default App;
