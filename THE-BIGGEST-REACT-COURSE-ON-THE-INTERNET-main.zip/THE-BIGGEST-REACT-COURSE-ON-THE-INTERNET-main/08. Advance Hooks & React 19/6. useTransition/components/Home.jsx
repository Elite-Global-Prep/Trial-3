const Home = () => <p>This is the Home component.</p>;
export default Home;
