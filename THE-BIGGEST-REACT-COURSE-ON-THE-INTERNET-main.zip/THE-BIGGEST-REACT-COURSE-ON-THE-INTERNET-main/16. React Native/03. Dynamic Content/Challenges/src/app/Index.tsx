import { View } from "react-native";
import CarComponent from "../components/CarComponent";

const Index = () => {
  return (
    <View>
      <CarComponent />
    </View>
  );
};

export default Index;
