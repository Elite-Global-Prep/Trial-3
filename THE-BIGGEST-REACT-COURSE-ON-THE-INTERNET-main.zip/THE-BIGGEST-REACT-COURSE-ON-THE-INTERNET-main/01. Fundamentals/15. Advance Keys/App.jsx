import Switcher from "./components/Switcher";

const App = () => {
  return (
    <div>
      <Switcher />
    </div>
  );
};
export default App;
