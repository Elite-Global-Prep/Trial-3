import { View, Text } from "react-native";

const AgeComponent = () => {
  return (
    <View>
      <Text>I'm 22 years old</Text>
    </View>
  );
};

export default AgeComponent;
