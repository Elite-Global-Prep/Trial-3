const Card = ({ children }) => {
  return <div>{children}</div>;
};

export default Card;
