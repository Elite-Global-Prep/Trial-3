import { View, Text, StyleSheet } from "react-native";

const ComponentA = () => {
  return <Text>This message is coming from Component A</Text>;
};

export default ComponentA;
