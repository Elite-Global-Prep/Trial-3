const MainContent = () => {
  return (
    <main>
      <h2>Main Content</h2>
      <p>This is the main content.</p>
    </main>
  );
};

export default MainContent;
