import { View, Text } from "react-native";
import st from "../style";

const AgeComponent = () => {
  return (
    <View style={st.shadowStyle}>
      <Text>I'm 22 years old</Text>
    </View>
  );
};

export default AgeComponent;
