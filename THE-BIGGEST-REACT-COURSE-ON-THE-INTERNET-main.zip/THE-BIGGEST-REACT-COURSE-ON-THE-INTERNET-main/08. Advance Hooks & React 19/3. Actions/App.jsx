import Form from "./component/Form";

const App = () => {
  return (
    <div>
      <Form />
    </div>
  );
};

export default App;
