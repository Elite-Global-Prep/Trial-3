// https://reactnative.dev/docs/text
import { Text } from "react-native";

const TextComponent = () => {
  return <Text>This is some random text coming from Text component</Text>;
};

export default TextComponent;
