// https://reactnative.dev/docs/view
import { Text, View } from "react-native";

const Index = () => {
  return (
    <View>
      <Text>Let's Explore View Component</Text>
      <Text>Hello World 1</Text>
      <Text>Hello World 2</Text>
    </View>
  );
};

export default Index;
