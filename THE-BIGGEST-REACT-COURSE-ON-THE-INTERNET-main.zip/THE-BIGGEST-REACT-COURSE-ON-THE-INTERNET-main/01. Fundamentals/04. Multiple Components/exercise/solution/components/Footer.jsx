const Footer = () => {
  return (
    <footer>
      <p>© 2024 My Website</p>
    </footer>
  );
};

export default Footer;
