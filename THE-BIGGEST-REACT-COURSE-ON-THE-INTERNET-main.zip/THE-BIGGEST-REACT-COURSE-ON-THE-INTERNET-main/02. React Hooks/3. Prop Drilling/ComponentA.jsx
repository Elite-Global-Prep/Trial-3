import ComponentB from "./ComponentB";

const ComponentA = ({ name }) => {
  return <ComponentB name={name} />;
};

export default ComponentA;
