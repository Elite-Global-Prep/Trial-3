import ComponentC from "./ComponentC";

const ComponentB = ({ name }) => {
  return <ComponentC name={name} />;
};

export default ComponentB;
