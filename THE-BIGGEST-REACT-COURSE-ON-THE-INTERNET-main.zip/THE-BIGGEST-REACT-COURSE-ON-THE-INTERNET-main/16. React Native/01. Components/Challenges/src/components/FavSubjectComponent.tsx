import { View, Text } from "react-native";

const FavSubjectComponent = () => {
  return (
    <View>
      <Text>I love Math</Text>
    </View>
  );
};

export default FavSubjectComponent;
