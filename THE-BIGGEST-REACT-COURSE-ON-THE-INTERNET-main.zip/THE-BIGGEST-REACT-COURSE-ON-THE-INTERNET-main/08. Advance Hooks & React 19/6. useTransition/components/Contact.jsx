const Contact = () => <p>This is the Contact component.</p>;
export default Contact;
