const Product = ({ name, price }) => {
  return (
    <div>
      <h1>Product Name: {name}</h1>
      <h1>Product Price: {price}</h1>
    </div>
  );
};

export default Product;
