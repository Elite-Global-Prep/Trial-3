"use client";

import MyComponent from "@/components/MyComponent";

export default function Home() {
  return (
    <>
      <MyComponent />
    </>
  );
}
