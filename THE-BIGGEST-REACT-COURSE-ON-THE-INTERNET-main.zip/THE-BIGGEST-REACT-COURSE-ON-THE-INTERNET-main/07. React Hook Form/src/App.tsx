import SimpleForm from "./components/SimpleForm";
import "./style.css";

function App() {
  return (
    <div>
      <SimpleForm />
    </div>
  );
}

export default App;
