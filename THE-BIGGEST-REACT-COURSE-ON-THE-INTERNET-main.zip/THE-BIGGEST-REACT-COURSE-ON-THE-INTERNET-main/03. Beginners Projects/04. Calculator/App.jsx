import Main from "./Main";

const App = () => {
  return (
    <div className="container">
      <Main />
    </div>
  );
};

export default App;
